# Skill: fs.diff

## Purpose
Show what changed before committing.

## Input
- paths (array)

## Output
- unified diff

## Notes
Mandatory before declaring completion.
