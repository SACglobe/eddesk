# Skill: storage.upload

## Purpose
Upload images/files to Supabase Storage.

## Bucket
- school-media

## Path Rule
- /{school_id}/...

## Input
- school_id
- file
- targetPath

## Output
- publicUrl
