# Skill: db.read

## Purpose
Read Supabase data.

## Allowed Tables
- schools
- school_domains
- school_content
- templates

## Forbidden
- Writes
- Service role unless explicitly allowed

## Input
- table
- filter

## Output
- records
