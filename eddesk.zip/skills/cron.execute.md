# Skill: cron.execute

## Purpose
Run scheduled maintenance tasks.

## Allowed Tasks
- reset-demo
- send-reminders

## Rules
- Demo schools only for reset
- Log every mutation

## Input
- taskName

## Output
- execution log
