import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import domain_data from './app/lib/constants';

export function proxy(request: NextRequest) {
    const url = request.nextUrl.clone();
    const host = request.headers.get('host') || '';
    const hostname = host.split(':')[0].toLowerCase().replace(/^www\./, '');

    console.log(`[EdDesk Proxy DEBUG] Request: ${url.pathname}, Host: ${host}, Method: ${request.method}`);

    // 0. IMMEDIATE BYPASS for internal/static
    if (url.pathname.startsWith('/_next') || url.pathname.startsWith('/api') || url.pathname.includes('.')) {
        return NextResponse.next();
    }

    // 0.1 EXPLICIT BYPASS for demo routes on local/owner
    if (url.pathname.startsWith('/demo')) {
        const isOwner = host.includes('localhost') || host.includes('127.0.0.1') || host.includes('eddesk.in');
        if (isOwner) {
            console.log(`[EdDesk Proxy DEBUG] Owner detected for demo route. BYPASSING proxy for: ${url.pathname}`);
            return NextResponse.next();
        } else {
            console.warn(`[EdDesk Proxy DEBUG] Non-owner blocked for demo route: ${host}`);
            return new NextResponse('Not Allowed', { status: 404 });
        }
    }

    // 1. Find the domain configuration
    const config = domain_data.find(d => d.domain === host) ||
        domain_data.find(d => d.domain === hostname);

    console.log(`[EdDesk Proxy DEBUG] Found Config:`, config?.domain || 'NONE', 'Type:', config?.type || 'NONE');

    // 2. Handle Owner Domains (Root Marketing)
    if (config?.type === 'owner' || host === 'localhost:3000' || host === '127.0.0.1:3000' || hostname === 'eddesk.in') {
        return NextResponse.next();
    }

    // 4. Handle Tenant Domains
    if (!url.pathname.startsWith('/tenant')) {
        url.pathname = `/tenant${url.pathname}`;
        console.log(`[EdDesk Proxy DEBUG] REWRITING to: ${url.pathname}`);
        return NextResponse.rewrite(url);
    }

    return NextResponse.next();
}

export default proxy;

export const config = {
    matcher: [
        /*
         * Match all request paths except for the ones starting with:
         * - api (API routes)
         * - _next/static (static files)
         * - _next/image (image optimization files)
         * - favicon.ico (favicon file)
         */
        '/((?!api|_next/static|_next/image|favicon.ico).*)',
    ],
};
