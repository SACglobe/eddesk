// src/templates/template_modern/index.ts
export * from './template.config'
export * from './index.tsx'
