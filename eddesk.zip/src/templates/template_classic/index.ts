// src/templates/template_classic/index.ts
export * from './template.config'
export * from './index.tsx'
