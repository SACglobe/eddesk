import FacultyScreen from "../../screens/FacultyScreen";

export default function Faculty() {
    return <FacultyScreen />;
}
