import ActivitiesScreen from "../../screens/ActivitiesScreen";

export default function Activities() {
    return <ActivitiesScreen />;
}
