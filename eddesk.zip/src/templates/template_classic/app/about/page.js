import AboutScreen from "../../screens/AboutScreen";

export default function About() {
    return <AboutScreen />;
}
