import ContactScreen from "../../screens/ContactScreen";

export default function Contact() {
    return <ContactScreen />;
}
