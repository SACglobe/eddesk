import PortraitScreen from "../../screens/PortraitScreen";

export default function Portrait() {
    return <PortraitScreen />;
}
