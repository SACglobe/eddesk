import InfrastructureScreen from "../../screens/InfrastructureScreen";

export default function Infrastructure() {
    return <InfrastructureScreen />;
}
