import BroadcastScreen from "../../screens/BroadcastScreen";

export default function Broadcast() {
    return <BroadcastScreen />;
}
