import DisclosureScreen from "../../screens/DisclosureScreen";

export default function Disclosures() {
    return <DisclosureScreen />;
}
