import AdmissionScreen from "../../screens/AdmissionScreen";

export default function Admission() {
    return <AdmissionScreen />;
}
