import AcademicsScreen from "../../screens/AcademicsScreen";

export default function Academics() {
    return <AcademicsScreen />;
}
