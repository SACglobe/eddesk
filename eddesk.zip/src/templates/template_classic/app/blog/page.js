import BlogListingScreen from "../../screens/BlogListingScreen";

export default function Blog() {
    return <BlogListingScreen />;
}
