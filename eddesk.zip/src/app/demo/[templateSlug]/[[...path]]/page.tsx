// src/app/demo/[templateSlug]/[[...path]]/page.tsx
//
// SSR-only Server Component for demo/preview routes.
// Accessible ONLY from owner domains (eddesk.in, localhost:*).
//
// Flow:
//   1. Validate templateSlug against VALID_SLUGS
//   2. Guard: notFound() if accessed from non-owner domain
//   3. fetchDemoScreen(templateSlug, screen)  → NO cache, domain always eddesk.in
//   4. buildTenantViewModel(payload)          → maps ScreenDataPayload → TenantViewModel
//   5. render template (NO subscription checks — demo bypasses all of them)
//
// Guardrails:
//   - No subscription checks — checkSubscription returns demo_bypass for mode='demo'
//   - No getSchoolByDomain call — demo does not have a registered domain
//   - templateSlug comes from URL param — validated against VALID_SLUGS server-side

import { headers } from 'next/headers';
import { notFound } from 'next/navigation';
import { fetchDemoScreen, pathToScreenName, normalizeDomain } from '@/core/services/screenData.service';
import { buildTenantViewModel } from '@/core/viewmodels/tenant.viewmodel';
import type { TenantState } from '@/core/context/TenantContext';
import TemplateRenderer from './TemplateRenderer';
import { generateTenantMetadata, generateSchoolJsonLd, generateAboutMetadata, generateAboutJsonLd } from '@/core/utils/seo';
import { Metadata } from 'next';
import LeadCapturePopup from '@/components/lead/LeadCapturePopup';

// Known valid template slugs
const VALID_SLUGS = ['template_classic', 'template_modern', 'template_premium'];

// Owner domains allowed to access demo routes
const OWNER_DOMAINS = ['eddesk.in', 'localhost', '127.0.0.1'];

export async function generateMetadata({
    params,
}: {
    params: Promise<{ templateSlug: string; path?: string[] }>
}): Promise<Metadata> {
    const { templateSlug, path: pathSegments } = await params;
    const screenName = pathSegments?.[0] || 'home';

    // Metadata for demo routes
    return {
        title: `Demo [${templateSlug}] - ${screenName.charAt(0).toUpperCase() + screenName.slice(1)} | EdDesk`,
        description: 'Previewing EdDesk school templates.',
        robots: { index: false, follow: false },
    };
}

export default async function TemplateDemoPage({
    params,
}: {
    params: Promise<{ templateSlug: string; path?: string[] }>
}) {
    const { templateSlug, path: pathSegments } = await params;
    const path = '/' + (pathSegments?.join('/') ?? '');
    const screenName = pathSegments?.[0] || 'home';

    // 1. Validate template slug
    if (!VALID_SLUGS.includes(templateSlug)) {
        return notFound();
    }

    // 2. Domain guard: Only allow owner domains
    const headersList = await headers();
    const host = headersList.get('host') || '';
    const hostname = normalizeDomain(host);
    const domainOnly = host.split(':')[0].toLowerCase();

    const isOwner = OWNER_DOMAINS.includes(domainOnly);
    if (!isOwner) {
        return notFound();
    }

    const result = await fetchDemoScreen(hostname, templateSlug, screenName);

    let tenantState: TenantState;

    if (result.status === 'success') {
        tenantState = {
            status: 'success',
            data: buildTenantViewModel(result.payload),
            message: '',
        };
    } else {
        // Handle error or empty state
        // DEMO BYPASS: If empty, pretend success so TemplateRenderer falls back to LOCAL_TENANT_DATA silently
        tenantState = {
            status: result.status === 'empty' ? 'success' : 'error',
            data: null as any,
            message: result.status === 'error' ? result.error : result.message,
        };
    }

    return (
        <>
            {tenantState.data && (
                <>
                    <script
                        type="application/ld+json"
                        dangerouslySetInnerHTML={{
                            __html: JSON.stringify(generateSchoolJsonLd(tenantState.data, hostname))
                        }}
                    />
                    {path === '/about' && (
                        <script
                            type="application/ld+json"
                            dangerouslySetInnerHTML={{
                                __html: JSON.stringify(generateAboutJsonLd(tenantState.data, hostname))
                            }}
                        />
                    )}
                </>
            )}
            <TemplateRenderer
                templateSlug={templateSlug}
                path={path}
                tenantState={tenantState}
            />
            <LeadCapturePopup templateSlug={templateSlug} />
        </>
    );
}
