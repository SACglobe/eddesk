describe('Smoke Test', () => {
    it('should pass', () => {
        expect(1 + 1).toBe(2);
    });
});
